/*******************************************************************************
* File Name: FSR10.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_FSR10_ALIASES_H) /* Pins FSR10_ALIASES_H */
#define CY_PINS_FSR10_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define FSR10_0			(FSR10__0__PC)
#define FSR10_0_PS		(FSR10__0__PS)
#define FSR10_0_PC		(FSR10__0__PC)
#define FSR10_0_DR		(FSR10__0__DR)
#define FSR10_0_SHIFT	(FSR10__0__SHIFT)
#define FSR10_0_INTR	((uint16)((uint16)0x0003u << (FSR10__0__SHIFT*2u)))

#define FSR10_INTR_ALL	 ((uint16)(FSR10_0_INTR))


#endif /* End Pins FSR10_ALIASES_H */


/* [] END OF FILE */
