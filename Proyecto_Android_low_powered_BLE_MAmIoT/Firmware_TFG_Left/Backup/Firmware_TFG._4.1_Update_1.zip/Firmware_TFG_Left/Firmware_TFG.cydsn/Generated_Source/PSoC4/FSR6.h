/*******************************************************************************
* File Name: FSR6.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_FSR6_H) /* Pins FSR6_H */
#define CY_PINS_FSR6_H

#include "cytypes.h"
#include "cyfitter.h"
#include "FSR6_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} FSR6_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   FSR6_Read(void);
void    FSR6_Write(uint8 value);
uint8   FSR6_ReadDataReg(void);
#if defined(FSR6__PC) || (CY_PSOC4_4200L) 
    void    FSR6_SetDriveMode(uint8 mode);
#endif
void    FSR6_SetInterruptMode(uint16 position, uint16 mode);
uint8   FSR6_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void FSR6_Sleep(void); 
void FSR6_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(FSR6__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define FSR6_DRIVE_MODE_BITS        (3)
    #define FSR6_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - FSR6_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the FSR6_SetDriveMode() function.
         *  @{
         */
        #define FSR6_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define FSR6_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define FSR6_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define FSR6_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define FSR6_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define FSR6_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define FSR6_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define FSR6_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define FSR6_MASK               FSR6__MASK
#define FSR6_SHIFT              FSR6__SHIFT
#define FSR6_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in FSR6_SetInterruptMode() function.
     *  @{
     */
        #define FSR6_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define FSR6_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define FSR6_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define FSR6_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(FSR6__SIO)
    #define FSR6_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(FSR6__PC) && (CY_PSOC4_4200L)
    #define FSR6_USBIO_ENABLE               ((uint32)0x80000000u)
    #define FSR6_USBIO_DISABLE              ((uint32)(~FSR6_USBIO_ENABLE))
    #define FSR6_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define FSR6_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define FSR6_USBIO_ENTER_SLEEP          ((uint32)((1u << FSR6_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << FSR6_USBIO_SUSPEND_DEL_SHIFT)))
    #define FSR6_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << FSR6_USBIO_SUSPEND_SHIFT)))
    #define FSR6_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << FSR6_USBIO_SUSPEND_DEL_SHIFT)))
    #define FSR6_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(FSR6__PC)
    /* Port Configuration */
    #define FSR6_PC                 (* (reg32 *) FSR6__PC)
#endif
/* Pin State */
#define FSR6_PS                     (* (reg32 *) FSR6__PS)
/* Data Register */
#define FSR6_DR                     (* (reg32 *) FSR6__DR)
/* Input Buffer Disable Override */
#define FSR6_INP_DIS                (* (reg32 *) FSR6__PC2)

/* Interrupt configuration Registers */
#define FSR6_INTCFG                 (* (reg32 *) FSR6__INTCFG)
#define FSR6_INTSTAT                (* (reg32 *) FSR6__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define FSR6_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(FSR6__SIO)
    #define FSR6_SIO_REG            (* (reg32 *) FSR6__SIO)
#endif /* (FSR6__SIO_CFG) */

/* USBIO registers */
#if !defined(FSR6__PC) && (CY_PSOC4_4200L)
    #define FSR6_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define FSR6_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define FSR6_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define FSR6_DRIVE_MODE_SHIFT       (0x00u)
#define FSR6_DRIVE_MODE_MASK        (0x07u << FSR6_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins FSR6_H */


/* [] END OF FILE */
